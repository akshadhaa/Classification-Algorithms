
ReadMe File
==========================================================SET UP AND BEGIN==================================================================================

1.  The Decision Tree algorithm was implemented using python and Jupyter Notebook
2.  Install anaconda jupter with python version 3.6
3.  Go to anaconda command prompt from start menu
4.  Go to directory of text file containing data where ipython file is saved
5.  Type: "jupyter notebook"  in command prompt to start jupyter notebook
6.  Open the ipython file for decision tree from the directory opened in notebook
7.  Input Parameters: 
	1. File path has to be given as a parameter to read the input file
	2. n_folds = Number of folds to be formed through k-fold  and 
	3. max_depth = maximum depth of the decision tree

8. Press Ctrl+Enter or "run" icon present at the top menu to run each of the block separately or go to "cell-> RunAll" to run the entire code at once

BY changing these parameters in the code and executing the cells of the notebook, the algorithm can be executed.

==================================================Decision Tree Classification Algorithm====================================================================
Python in-built packages installed are:
1. Random package is used  for seeding and random values 
2. Numpy package is used for array packaging 
3. Pandas packages isused for handeling data structures
4. from sklearn package, preprocessing algorithm is imported for normalizing decision tree learning

 - Currently, continuous and discrete datasets can be learned.
 - Discrete model assumes unique labels 
  -Tree can be visualized through code for analysis
 - Continuous looks at all possible values for a variable and iteratively chooses the best threshold between all possible assignments. 
   This results in a binary DFS tree which is partitioned by the threshold at every step.


=========================================================CONTACT=============================================================================================
Please send bug reports, patches, and other feedback to saaniaus@buffalo.edu
=============================================================================================================================================================