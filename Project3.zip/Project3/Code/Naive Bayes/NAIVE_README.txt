ReadMe File
==========================================================SET UP AND BEGIN==================================================================================

1.  The NAIVE BAYES algorithm was implemented using python and Jupyter Notebook
2.  Install anaconda jupter with python version 3.6
3.  Go to anaconda command prompt from start menu
4.  Go to directory of text file containing data where ipython file is saved
5.  Type: "jupyter notebook"  in command prompt to start jupyter notebook
6.  Open the ipython file for decision tree from the directory opened in notebook
7.  Input Parameters: 
	1. File path has to be given as a parameter to read the input file
	2. n_folds = Number of folds to be formed through k-fold  and 
	

8. Press Ctrl+Enter or "run" icon present at the top menu to run each of the block separately or go to "cell-> RunAll" to run the entire code at once

BY changing these parameters in the code and executing the cells of the notebook, the algorithm can be executed.

==================================================NAIVE BAYES Classification Algorithm====================================================================
Python in-built packages installed are:
1. Random package is used  for seeding and random values 
2. Numpy package is used for array packaging 
3. Pandas packages isused for handeling data structures
4. from sklearn package, preprocessing algorithm is imported for normalizing decision tree learning

- We also need to give an integer value for k_val.(Preferably an odd integer, to avoid disputes among the class votes ie., class0 and class1 values.) 
 - Currently, continuous and discrete datasets can be learned.
- The attributes of dataset should be independent. If not, one should preprocess the dataset such that all the attributes are independent of each other.
 - Discrete model assumes unique labels.
 - Continuous looks at all possible values for a variable and iteratively chooses the best threshold between all possible assignments. 
   This result is a list of precision, accuracy, recall and F-1 score for k folds of dataset, and mean of all the folds.
=========================================================CONTACT=============================================================================================
Please send bug reports, patches, and other feedback to akshadha@buffalo.edu
=============================================================================================================================================================